<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\ProductoModel;

class ProductoController extends ResourceController
{
    protected $productoModel;

    public function __construct()
    {
         $this->productoModel = new ProductoModel();


    }
    /**
     * Return an array of resource objects, themselves in array format
     *
     * @return mixed
     */
    public function index()
    {
        $productos = $this->ProductoModel->orderBy('id', 'asc')->findAll();
        $data = [
            'productos' => $productos
        ];
        return $this->response->setJSON($data);
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function show($id = null)
    {
        //
        if ($productos = $this->ProductoModel->find($id)) {			

			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("Un error a ocurrido");			

		}else{

			return $this->response->setJSON($data);
		}	
		
    }

    /**
     * Return a new resource object, with default properties
     *
     * @return mixed
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters
     *
     * @return mixed
     */
    public function create()
    {
        //
        $rules = [
			'nombre' => [
				'rules'  => 'required',
				'errors' => [
					'required' => 'Nombre '
				]
			],
			'descripcion' => [
				'rules'  => 'required',
				'errors' => [
					'required' => 'Descripcion '
				]
			],
			'imagen' => [
				'rules'  => 'required',
				'errors' => [
					'required' => 'Imagen '
				]
			],
			'precio'    => [
				'rules'  => 'required',
				'errors' => [
					'required' => 'precio',
					
				]
			],
            'estado'    => [
				'rules'  => 'required|valid_email',
				'errors' => [
					'required' => 'estado',
					
				]
			],
		];		

		$data = $this->request->getPost();		

			$data = $this-> ProductoModel->save($data);

			return $this->response->setJSON($data);
		}		
    

    /**
     * Return the editable properties of a resource object
     *
     * @return mixed
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        //
        $data = $this->request->getRawInput();		

		if ($productos = $this->ProductoModel->find($id)) {

			return $this->failNotFound('Usuario con  id nro:'.$id.' no encontrado.');
			
		}else{

			$data['productos'] = $this->ProductoModel->update($id,$data);

			return $this->response->setJSON($data);
		}	
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        //
        if ($data = $this->ProductoModel->delete($id)) {			

			return $this->responseDeleted();			
		}
    }
}
